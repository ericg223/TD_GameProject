import processing.core.PApplet;
import java.util.ArrayList;

public class Map{
    PApplet p;
    public Map(PApplet p) {
        this.p = p;
    }
   
    public void map1() {
        p.fill(125);
        for (int x = 50; x < 500; x+= 64) {
            for (int y = 75; y < 450; y+= 64) {
                p.rect(x, y, 64, 64);
            }
        } 

    }

    public void map2() {
      
    }
    public void tree(int x, int y) {
     
        p.fill(32,32,32);
        p.rect(x+65, y+105, 10, 25);
        p.fill(76, 153, 0);
        p.triangle(x+70,y+95,x+50,y+115,x+90,y+115);
        p.triangle(x+70,y+85,x+50,y+105,x+90,y+105);
        p.triangle(x+70,y+75,x+50,y+95,x+90,y+95);
    }

}