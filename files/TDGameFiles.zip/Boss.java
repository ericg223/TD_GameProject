import processing.core.PApplet;
import processing.core.PImage;
import java.util.ArrayList;
public class Boss extends Enemy{
    private int rowSize;
    public Boss(PApplet p, PImage enemy, String name, int health, int speed, int damage,int xPos, int yPos, int row, int rowSize) {
        super(p, enemy, name, health, speed, damage, xPos, yPos, row);
        this.rowSize = rowSize;
    }
  

    public boolean attackTower() {
        return true;
    }
    public int getRowSize() {
        return rowSize;
    }
   
  

}