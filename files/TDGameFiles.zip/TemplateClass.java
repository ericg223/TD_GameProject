import processing.core.PApplet;

public class TemplateClass{
    PApplet p;
    public TemplateClass(PApplet p) {
        this.p = p;
    }
   
  

}