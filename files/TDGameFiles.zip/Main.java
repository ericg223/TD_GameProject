
import processing.core.PApplet;
import javax.sound.sampled.*;
import java.io.File;
import java.io.IOException;
import java.util.Scanner;
//import processing.sound.*;

public class Main {

 public static void main(String[] args) {
    System.out.println("Hello, welcome to my tower defense game!");
    System.out.println("This game is inspire by Plants vs Zombie and has very similar mechanic");
    System.out.println("Click on a tower then place it somewhere on the grid to fight off the enemies");
    System.out.println("\u001B[33m" + "Tip: Right click on each tower to get a description of each tower. (The same place where you buy your towers)" + "\u001B[0m");
    PApplet.main("Sketch");
   

 }
}
