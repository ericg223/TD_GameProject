import processing.core.PApplet;
import processing.core.PImage;
import java.util.ArrayList;
public class Enemy{
    PApplet p;
    PImage enemy;
    private int maxHealth, health, damage;
    private int speed;
    private String name;
    private int xPos;
    private int yPos;
    private int row;
    public Enemy(PApplet p, PImage enemy, String name, int health, int speed, int damage,int xPos, int yPos, int row) {
        this.p = p;
        this.name = name;
        this.health = health;
        this.maxHealth = health;
        this.speed = speed;
        this.damage = damage;
        this.enemy = enemy;
        this.xPos = xPos;
        this.yPos = yPos;
        this.row = row;
    }
    public void updateHealth(int damage) {
        health -= damage;   
    }
    public void updateEnemy(int loop) {
        
        if (loop % 60 == 0) {
            xPos -= speed;
        }
        
        p.image(enemy, (float) xPos, (float) yPos);
    }
    public boolean attackTower() {
        return true;
    }
    public int getReward() {
        return maxHealth * 2;
    }
    public int getHealth() {
        return health;
    }
    public int getXPos() {
        return xPos;
    }
    public int getYPos() {
        return yPos;
    }
    public int getRow() {
        return row;
    }
   
  

}