import processing.core.PApplet;
import processing.core.PImage;
import java.util.ArrayList;
public class StoneHead extends Tower{
    private PApplet p;
    public StoneHead(PApplet p, double price, int xPos, int yPos, int row, int health) {
        super(p, price, xPos, yPos, row, health);
        this.p = p;
        
    }

    public void playTowerAnimation(PImage stoneHead1, PImage stoneHead2, PImage stoneHead3, PImage stoneHead4, int loop) {
        int health = super.getHealth();
        if (health >= 54) {
            p.image(stoneHead1, (float) super.getXPos(), (float) super.getYPos());
        } else if (health >= 36) {
            p.image(stoneHead2, (float) super.getXPos(), (float) super.getYPos());
        } else if (health >= 18) {
            p.image(stoneHead3, (float) super.getXPos(), (float) super.getYPos());
        } else {
            p.image(stoneHead4, (float) super.getXPos(), (float) super.getYPos());
        }
    }

}