import processing.core.PApplet;
import processing.core.PImage;
public class Tower  {
    private double price;
    private int row, xPos, yPos, health;
    PApplet p;

    public Tower(PApplet p, double price, int xPos, int yPos, int row, int health) {
        this.p = p;
        this.price = price;
        this.xPos = xPos;
        this.yPos = yPos;
        this.row = row;
        this.health = health;
    }
    public int getRow() {
        return row;
    }
    public int getXPos() {
        return xPos;
    }

    public int getYPos() {
        return yPos;
    }
    
    public void fireProjectile() { //cannons only
        System.out.println("Error in fireProjectile Tower.java");
    }
    public void fireProjectile(String effect) {
        System.out.println("Error in fireProjectile Tower.java");

    }

    public void updateProjectiles(PImage cannonBullet) { //cannons only
        System.out.println("Error in updateProjectile Tower.java");
    }
    public void playTowerAnimation(PImage cannon1, PImage cannon2, int loop) { //currently for cannons only
        System.out.println("Error in playTowerAnimation");
    }
    public void playTowerAnimation(PImage cannon1, PImage cannon2, PImage cannon3, PImage cannon4, int loop) { //currently for mythic cannons only
        System.out.println("Error in playTowerAnimation");
    }
    public void playTowerAnimation(PImage appleTree1, PImage appleTree2, PImage appleTree3, int time) { //currently for appleTree only
        System.out.println("Error in playTowerAnimation");
    }
    public int collectMoney() {
        //currently for appleTree only
        System.out.println("Error in playTowerAnimation");
        return 0;
    }
    public boolean damaged(int damage) {
        health -= damage;
        return health <= 0;
    
    }
    public int getHealth() {
        return health;
    }
  

}