import processing.core.PApplet;
import processing.core.PImage;
import java.util.ArrayList;
public class Enemy{
    PApplet p;
    PImage enemy;
    private int maxHealth, health, damage;
    private int speed;
    private String name;
    private int xPos;
    private int yPos;
    private int row;
    private int slowCount = 0;
    private Tower[] towers; 
    public Enemy(PApplet p, PImage enemy, String name, int health, int speed, int damage,int xPos, int yPos, int row, Tower[] towers) {
        this.p = p;
        this.name = name;
        this.health = health;
        this.maxHealth = health;
        this.speed = speed;
        this.damage = damage;
        this.enemy = enemy;
        this.xPos = xPos;
        this.yPos = yPos;
        this.row = row;
        this.towers = towers;
    }
    public void updateWalkSpeed(double percent) {
        if (slowCount <= 3) {
            double temp = speed * (1-percent);
            speed = (int) temp;
            slowCount++;
            System.out.println("Applied Slow");
        }
    }
    public void updateHealth(int damage) {
        health -= damage;   
    }
    public void updateEnemy(int loop) {
        
        if (loop % 60 == 0) {
            xPos -= speed;
        }
        
        p.image(enemy, (float) xPos, (float) yPos);
    }
    public void changeImage(PImage image) {
        enemy = image;
        
    }
    public boolean attackTower() {
        for (int i = 0; i < towers.length; i++) {
            if (towers[i] != null) {
                int towerXPos = towers[i].getXPos();
                if (xPos-towerXPos >= 0 && xPos-speed < towerXPos  || (getXPos()-towerXPos <= 0 && getXPos()+10 > towerXPos)) {

                    xPos += speed+5;
                    return towers[i].damaged(damage);
                }
            }
            
        }

        return false;
    }
    public void fireBreathAttack() {

    }
    public void updateProjectiles(PImage attack) {
 
    }
    public int getSpeed() {
        return speed;
    }
    public int getReward() {
        return maxHealth * 5;
    }
    public int getHealth() {
        return health;
    }
    public int getXPos() {
        return xPos;
    }
    public int getYPos() {
        return yPos;
    }
    public int getRow() {
        return row;
    }
    public void setRow(int row) {
        this.row = row;
    }
    public void updateXPos(int xPos) {
        this.xPos += xPos;
    }   
    public int getDamage() {
        return damage;
    }
    public void setYPos(int yPos) {
        this.yPos = yPos;
    }
  

}