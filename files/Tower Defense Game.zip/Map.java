import processing.core.PApplet;
import java.util.ArrayList;
import processing.core.PImage;
public class Map{
    PApplet p;
    private ArrayList<Effect> effects = new ArrayList<Effect>();
    private ArrayList<Projectile> projectiles = new ArrayList<Projectile>();
    private PImage lavaBackground, flame, fallingRocks,dragonBirdEyeView ;
    private int red, green, blue = 0;
    Tower[][] towers;
    public Map(PApplet p, Tower[][] towers) {
        this.p = p;
        this.towers = towers;

    }
    public void setup() {
        lavaBackground = p.loadImage("Sprites/Others/lavaFloor.jpg");
        flame = p.loadImage("Sprites/Effects/Flame.png");
        fallingRocks = p.loadImage("Sprites/Effects/FallingRocks.png");
        dragonBirdEyeView = p.loadImage("Sprites/Others/DragonBirdEyeView.png");
    }
    public void map1() {
        
        p.fill(125);
        for (int x = 50; x < 500; x+= 64) {
            for (int y = 75; y < 450; y+= 64) {
                p.rect(x, y, 64, 64);
            }
        } 
        updateEffects();

    }
    public void map3(int time) {
        
        p.fill(125);
        
        for (int x = 50; x < 500; x+= 64) {
            
            for (int y = 75; y < 450; y+= 64) {
             
                red = (int) (Math.random() * 140)+115;
                green = (int) (Math.random() * 140)+115;
                blue = (int) (Math.random() * 140)+115;
                 
                p.fill(red, green, blue);
                p.rect(x, y, 64, 64);
            }
        } 
        updateEffects();

    }

    public void map2(PImage background, int enemyLoop) {
        int row = (int) (Math.random() * 6);
        int col = (int) (Math.random() * 8);
        p.image(lavaBackground,0,0);
        p.fill(125,0,0);
        for (int x = 50; x < 500; x+= 64) {
            for (int y = 75; y < 450; y+= 64) {
                
                p.rect(x, y, 64, 64);
            }
        } 
        if (enemyLoop % 15 == 0) {
            effects.add(new Effect(1, row, col));
            if (towers[row][col] != null) {
                if (towers[row][col].getHealth() <= 12) {
                    effects.add(0, new Effect(1, row, col, flame));
                }
                towers[row][col].damaged(1);
            }
            
        }
        updateEffects();
        if (enemyLoop == 3501) { //bosstime
            transitionMap();
        }
        for (int i = 0; i < projectiles.size(); i++) {
            projectiles.get(i).updateProjectile(3,0);
            p.image(dragonBirdEyeView, projectiles.get(i).getXPos(), projectiles.get(i).getYPos());
        }
     
    }
    public void transitionMap() {
        projectiles.add(new Projectile(0,-500,0,0));
        

    }
    public void updateEffects() {
        for (int i = effects.size() - 1; i >= 0; i--) {
            int time = effects.get(i).getTime();
            effects.get(i).addTime();
            if (time > 120) {
                effects.remove(i);
            } else {
                p.fill(255,0,0);
                int row = effects.get(i).getRow();
                int col = effects.get(i).getCol();
                PImage image = effects.get(i).getImage();                
                if (image != null) {
                    p.image(image,50+64*col, 50+64*row);
                } else {
                    p.rect(50+64*col, 75+64*row, 64,64);
                }
            }
        }
    
    }
    public void flameRow(int row) {
        for (int col = 0; col < 8; col++) {
            effects.add(0, new Effect(1, row, col, flame));
            effects.add(new Effect(1, row, col));
            if (towers[row][col] != null) {
                towers[row][col].damaged(6);
            }
        }
        
    }


    public void tree(int x, int y) {
     
        p.fill(32,32,32);
        p.rect(x+65, y+105, 10, 25);
        p.fill(76, 153, 0);
        p.triangle(x+70,y+95,x+50,y+115,x+90,y+115);
        p.triangle(x+70,y+85,x+50,y+105,x+90,y+105);
        p.triangle(x+70,y+75,x+50,y+95,x+90,y+95);
    }

}