import processing.core.PApplet;
import processing.core.PImage;
import java.util.ArrayList;
public class Effect{

    private int damage, col, row, time;
    private PImage image;
    public Effect(int damage, int row, int col) {
        this.damage = damage;
    
        this.row = row;
        this.col = col;
        this.time = 0;
    }
    public Effect(int damage, int row, int col, PImage image) {
        this.damage = damage;

        this.row = row;
        this.col = col;
        this.time = 0;
        this.image = image;
    }
    public PImage getImage() {
        return image;
    }
    public int getRow() {
        return row;
    }
    public int getCol() {
        return col;
    }

    public void addTime() {
        time++;
    }
    public int getTime() {
        return time;
    }

}