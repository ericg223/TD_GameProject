import processing.core.PApplet;
import processing.core.PImage;
import java.util.ArrayList;
public class Boss extends Enemy{
    private int rowSize;
    private Tower[][] towers;
    private PApplet p;
    private ArrayList<Projectile> projectiles = new ArrayList<Projectile>();

    public Boss(PApplet p, PImage enemy, String name, int health, int speed, int damage,int xPos, int yPos, int row, Tower[][] towers, int rowSize) {
        super(p, enemy, name, health, speed, damage, xPos, yPos, row, towers[row]);
        this.rowSize = rowSize;
        this.towers = towers;
        this.p = p;

    }
  
    public boolean attackTower() {
    
        for (int i = super.getRow(); i < super.getRow() +rowSize; i++) {
            for (int j = 0; j < towers[i].length; j++) {
                if (towers[i][j] != null) {
                    int towerXPos = towers[i][j].getXPos();
                    if ((super.getXPos()-towerXPos >= 0 && super.getXPos()-super.getSpeed() < towerXPos)  || (super.getXPos()-towerXPos <= 0 && super.getXPos()+50 > towerXPos)) {
                        
                        
                        projectiles.add(new Projectile(0, towerXPos, towers[i][j].getYPos(), 0));
                        
                        super.updateXPos(super.getSpeed()+15);
                        return towers[i][j].damaged(super.getDamage());
                    }
                }
            }
            
            
            
        }
        updateProjectiles();

        return false;
    }
    public void updateProjectiles() {
        PImage attack = p.loadImage("Sprites/Others/Crack.png");
        for (int i = projectiles.size()-1; i >= 0 ; i--) {
            projectiles.get(i).addTime();
            if (projectiles.get(i).getTime() >= 120) {
                projectiles.remove(i);
            } else {
                p.image(attack, projectiles.get(i).getXPos(), projectiles.get(i).getYPos());
            }

        }
    }
 
    public int getRowSize() {
        return rowSize;
    }
   
  

}