import processing.core.PApplet;
import processing.core.PImage;
import java.util.ArrayList;
public class Farm extends Tower{
    private PApplet p;
    private int stageLevel = 1;
    public Farm(PApplet p, double price, int xPos, int yPos, int row, int health) {
        super(p, price, xPos, yPos, row, health);
        this.p = p;
        
    }

    public int collectMoney() {
        if (stageLevel == 1) {
            System.out.println("No apples here!");
            return 0;
        } else if (stageLevel == 2) {
            System.out.println("+25");
            System.out.println("\u001B[33m"+"Tip: Next time, wait for there to be 6 apples before collecting" + "\u001B[0m");
            stageLevel = 1;
            return 25;
        } else {
            System.out.println("+$100");
            stageLevel = 1;
            return 100;
        }
        
    }
    public void playTowerAnimation(PImage appleTree1, PImage appleTree2, PImage appleTree3, int loop) {
        p.fill(255,255,255);
        p.stroke(51);
        p.strokeWeight(4);
        
        if (stageLevel == 1) {
            
            if (loop%600 == 0) {
                stageLevel = 2;
                p.text("Harvest", (float) super.getXPos()-25, (float) super.getYPos()+25);
                p.image(appleTree2, (float) super.getXPos(), (float) super.getYPos());
                return;
            } 
            p.image(appleTree1, (float) super.getXPos(), (float) super.getYPos());
            return;
        } else if (stageLevel == 2) {
            if (loop%1500 == 0) {
                stageLevel = 3;
                p.image(appleTree3, (float) super.getXPos(), (float) super.getYPos());
                
                p.text("Harvest", (float) super.getXPos()-25, (float) super.getYPos()+25);
                return;
            }
            p.image(appleTree2, (float) super.getXPos(), (float) super.getYPos());
            
        } else {
            p.image(appleTree3, (float) super.getXPos(), (float) super.getYPos());
        }
        
        p.text("Harvest", (float) super.getXPos()-25, (float) super.getYPos()+25);

    }
   
   
  

}