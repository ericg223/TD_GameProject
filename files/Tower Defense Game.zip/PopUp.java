import processing.core.PApplet;
import processing.core.PImage;
public class PopUp{
    private PApplet p;
    private String item, stuff;
    private int apperance;
    public PopUp(PApplet p, String item, String stuff) {
        this.p = p;
        this.item = item;
        this.stuff = stuff;
    }
   
    public int show() {
        apperance++;
        if (item.equals("money")) {
            int money = Integer.parseInt(stuff);
            if (money < 0) {
                p.fill(255,0,0);
                p.text(stuff, 50, 530-apperance);
            } else if (money > 0){
                p.fill(0,255,0);
                p.text("+" + stuff, 50,530-apperance);
            } else {
                apperance += 500;
            }
        }
        return apperance;
    }
  

}