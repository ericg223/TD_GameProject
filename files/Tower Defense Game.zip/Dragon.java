import processing.core.PApplet;
import processing.core.PImage;
import java.util.ArrayList;
public class Dragon extends Boss{
    private int rowSize;
    private Tower[][] towers;
    private PApplet p;
    private ArrayList<Projectile> projectiles = new ArrayList<Projectile>();
    private ArrayList<Projectile> fireBreaths = new ArrayList<Projectile>();
    private Map map;
    private PImage fireBreath, slash, dragon2, dragon1, dragon3;
    public Dragon(PApplet p, PImage enemy, String name, int health, int speed, int damage,int xPos, int yPos, int row, Tower[][] towers, int rowSize, Map map) {
    
        super(p, enemy, name, health, speed, damage, xPos, yPos, row, towers, rowSize);
        this.rowSize = rowSize;
        this.towers = towers;
        this.p = p;
        this.map = map;
    }
    public void setup() {
        fireBreath = p.loadImage("Sprites/Effects/FireBreath.png");
        slash = p.loadImage("Sprites/Effects/Slash.png");
        dragon1 = p.loadImage("Sprites/Enemies/Dragon1.png");
        dragon2 = p.loadImage("Sprites/Enemies/Dragon2.png");
        dragon3 =  p.loadImage("Sprites/Enemies/Dragon3.png");
    }
    public boolean attackTower() {

        for (int i = super.getRow(); i < super.getRow() + rowSize; i++) {
            for (int j = 0; j < towers[i].length; j++) {
                if (towers[i][j] != null) {
                    int towerXPos = towers[i][j].getXPos();
                    if ((super.getXPos()-towerXPos >= 0 && super.getXPos()-10 < towerXPos) || (super.getXPos()-towerXPos <= 0 && super.getXPos()+50 > towerXPos)) {
                        
                        changeImage(dragon2);
                        projectiles.add(new Projectile(0, towerXPos, towers[i][j].getYPos(), 0));
                        
                        super.updateXPos(super.getSpeed()+15);
                        return towers[i][j].damaged(super.getDamage());
                    }
                } 
            }
            
            
            
        }
        updateProjectiles(slash);
        updateFireBreath();
        return false;
    }
    public void fireBreathAttack() {
        int newRow = (int) (Math.random() * 4);

        setYPos(25+newRow*64);
        setRow(newRow);
        map.flameRow(newRow);
        fireBreaths.add(new Projectile(0, 600+super.getXPos()-750, super.getYPos()+75, 0));
        updateFireBreath();
        updateProjectiles(slash);
        changeImage(dragon3);

    }
    public void updateProjectiles(PImage attack) {
        for (int i = projectiles.size()-1; i >= 0 ; i--) {
            projectiles.get(i).addTime();
            if (projectiles.get(i).getTime() >= 120) {
                projectiles.remove(i);

            } else {
                p.image(attack, projectiles.get(i).getXPos(), projectiles.get(i).getYPos());
                if (projectiles.get(i).getTime() >= 60) {
               
                    changeImage(dragon1);
                }
            }

        }
    }
    public void updateFireBreath() {
        for (int i = fireBreaths.size()-1; i >= 0 ; i--) {
            fireBreaths.get(i).addTime();
            if (fireBreaths.get(i).getTime() >= 120) {
                fireBreaths.remove(i);

            } else {
                p.image(fireBreath, fireBreaths.get(i).getXPos(), fireBreaths.get(i).getYPos());
                if (fireBreaths.get(i).getTime() >= 60) {
                    changeImage(dragon1);
                }
            }

        }
    }
    public int getRowSize() {
        return rowSize;
    }
   
  

}