import processing.core.PApplet;
import processing.core.PImage;
import java.util.ArrayList;
public class MythicCannon extends Cannon{

    public MythicCannon(PApplet p, int damage, double fireRate, double price, int xPos, int yPos, int row, ArrayList<Enemy> enemies, ArrayList<Boss> bosses, int health) {
        super(p, damage, fireRate, price, xPos, yPos, row, enemies, bosses, health);
      
    }


}