import processing.core.PApplet;
import processing.core.PImage;
import javax.sound.sampled.*;
import java.io.File;
import java.util.Arrays;


import java.util.ArrayList;

public class Sketch extends PApplet {
    int baseHealth, maxHealth, cash;
    int loop, enemyLoop, time = 0;
    
    PImage cannon1, cannon2, cannonBullet, cannon1Copy;
    PImage mythicCannon1, mythicCannon2, mythicCannon3, mythicCannon4, mythicCannon1Copy, mythicCannonBullet;
    PImage snowCannon1, snowCannon2, snowCannon1Copy, snowCannonBullet;
    PImage appleTree1, appleTree2, appleTree3, appleTree1Copy;
    PImage DJ1, DJ2, DJ3, DJ1Copy;
    PImage stoneHead1, stoneHead2, stoneHead3, stoneHead4, stoneHead1Copy;
    PImage lavaBackground, fallingRocks;
    int numOfDJ, enemyCount = 0;
    PImage trash;
    String lastTowerSelected, showTowerInfo = "null";
    boolean isTrashing, placingTower, lost, win = false;
    PImage slime, boss, skeleton; //enemies
    int[] cooldowns = new int[6]; //cooldown to place the 6 towers
    ArrayList<PopUp> popUps = new ArrayList<PopUp>(); //There are random amounts of popups.
    ArrayList<Enemy>[] enemies = new ArrayList[6]; //Fix number of rows but random amount of zombies
    ArrayList<Boss> bosses = new ArrayList<Boss>(); //I plan to make bosses take up multiple rows, so I can't use 2D arrays
    Tower[][] towers = new Tower[6][8]; //Fix number of towers
    PImage dragon1, dragon2, dragon3, dragon4;
    Map map = new Map(this, towers);
    int bossTime = 8000;
    public void settings() {
        size(600, 600);
        //Player's stats that you can change
        maxHealth = 500;
        baseHealth = 500;
        cash = 500;
        time = 0;
        enemyLoop = 0;
    }

    public void setup() {
        for (int i = 0; i < enemies.length; i++) {
            enemies[i] = new ArrayList<Enemy>();
        }
        strokeWeight(1);
        stroke(51);
        map.setup();
  
        cannon1 = loadImage("Sprites/Towers/Cannon/Cannon1.png");
        cannon1Copy = loadImage("Sprites/Towers/Cannon/Cannon1.png");
        cannon2 = loadImage("Sprites/Towers/Cannon/Cannon2.png");
        cannonBullet = loadImage("Sprites/Towers/Cannon/CannonBullet.png");
        appleTree1 = loadImage("Sprites/Towers/AppleTree/AppleTreeStage1.png");
        appleTree1Copy = loadImage("Sprites/Towers/AppleTree/AppleTreeStage1.png");
        appleTree2 = loadImage("Sprites/Towers/AppleTree/AppleTreeStage2.png");
        appleTree3 = loadImage("Sprites/Towers/AppleTree/AppleTreeStage3.png");
        DJ1 = loadImage("Sprites/Towers/DJ/DJ1.png");
        DJ2 = loadImage("Sprites/Towers/DJ/DJ2.png");
        DJ3 = loadImage("Sprites/Towers/DJ/DJ3.png");
        DJ1Copy = loadImage("Sprites/Towers/DJ/DJ1Copy.png");
        mythicCannon1 = loadImage("Sprites/Towers/MythicCannon/MythicCannon1.png");
        mythicCannon1Copy = loadImage("Sprites/Towers/MythicCannon/MythicCannon1.png");
        mythicCannon2 = loadImage("Sprites/Towers/MythicCannon/MythicCannon2.png");
        mythicCannon3 = loadImage("Sprites/Towers/MythicCannon/MythicCannon3.png");
        mythicCannon4 = loadImage("Sprites/Towers/MythicCannon/MythicCannon4.png");
        mythicCannonBullet = loadImage("Sprites/Towers/MythicCannon/MythicCannonBullet.png");
        snowCannon1 = loadImage("Sprites/Towers/SnowCannon/SnowCannon1.png");
        snowCannon1Copy = loadImage("Sprites/Towers/SnowCannon/SnowCannon1.png");
        snowCannon2 = loadImage("Sprites/Towers/SnowCannon/SnowCannon2.png");
        snowCannonBullet = loadImage("Sprites/Towers/SnowCannon/SnowCannonBullet.png");
        stoneHead1 = loadImage("Sprites/Towers/StoneHead/StoneHead1.png");
        stoneHead1Copy = loadImage("Sprites/Towers/StoneHead/StoneHead1.png");
        stoneHead2 = loadImage("Sprites/Towers/StoneHead/StoneHead2.png");
        stoneHead3 = loadImage("Sprites/Towers/StoneHead/StoneHead3.png");
        stoneHead4 = loadImage("Sprites/Towers/StoneHead/StoneHead4.png");
        trash = loadImage("Sprites/Others/Trash.png");
        slime = loadImage("Sprites/Enemies/Slime.png");
        boss = loadImage("Sprites/Enemies/Boss.png");
        skeleton = loadImage("Sprites/Enemies/Skeleton.png");
        dragon1 = loadImage("Sprites/Enemies/Dragon1.png");
        fallingRocks = loadImage("Sprites/Effects/FallingRocks.png");
  
 
    }

    public void draw() {
        strokeWeight(1);
        loop += 1+numOfDJ;
        enemyLoop++;
        time++;
        if (win) {
            frameRate(1);
        } else {
            frameRate(60);
        }

        background(150);
        if (time < bossTime) {
            map.map1();
        } else if (win){
            map.map3(time);
        } else {
            map.map2(lavaBackground, time);
    
        }
        
        
        
        characterBar();
        if (!lost) {
            strokeWeight(1);
            imageMode(CENTER);
            if (placingTower) {
                fill(255,0,0);
                textSize(40);
                text("Press Q to cancel",145,415);
                if (lastTowerSelected.equals("slot1")) {
                    cannon1Copy.filter(THRESHOLD);
                    image(cannon1Copy, mouseX, mouseY);
                } else if (lastTowerSelected.equals("slot2")) {
                    appleTree1Copy.filter(THRESHOLD);
                    image(appleTree1Copy, mouseX, mouseY);
                } else if (lastTowerSelected.equals("slot3")) {
                    DJ1Copy.filter(THRESHOLD);
                    image(DJ1Copy, mouseX, mouseY+50);
                } else if (lastTowerSelected.equals("slot4")) {
                    mythicCannon1Copy.filter(THRESHOLD);
                    image(mythicCannon1Copy, mouseX, mouseY);
                } else if (lastTowerSelected.equals("slot5")) {
                    snowCannon1Copy.filter(THRESHOLD);
                    image(snowCannon1Copy, mouseX, mouseY);
                } else if (lastTowerSelected.equals("slot6")) {
                    stoneHead1Copy.filter(THRESHOLD);
                    image(stoneHead1Copy, mouseX, mouseY);
                }
            }

            if (isTrashing) {
                fill(255,0,0);
                textSize(40);
                text("Press Q to cancel",145,415);
                image(trash, mouseX, mouseY);
            }
            textSize(20);
            numOfDJ = 0;
            for (int i = 0; i < towers.length; i++) { //row
                for (int j = 0; j < towers[i].length; j++) { //col
                    
                    if (towers[i][j] != null) {
                        if (towers[i][j] instanceof MythicCannon) {
                            towers[i][j].playTowerAnimation(mythicCannon1, mythicCannon2, mythicCannon3, mythicCannon4, loop);
                        } else if (towers[i][j] instanceof SnowCannon) {
                            towers[i][j].playTowerAnimation(snowCannon1, snowCannon2, loop);
                        } else if (towers[i][j] instanceof Cannon) {
                            towers[i][j].playTowerAnimation(cannon1, cannon2, loop);
                        } else if (towers[i][j] instanceof Farm) {
                            towers[i][j].playTowerAnimation(appleTree1, appleTree2, appleTree3, loop);
                        } else if (towers[i][j] instanceof DJ) {
                            numOfDJ = 1;
                            towers[i][j].playTowerAnimation(DJ1, DJ2, DJ3, time);
                    
                        } else if (towers[i][j] instanceof StoneHead) {
                            towers[i][j].playTowerAnimation(stoneHead1, stoneHead2, stoneHead3, stoneHead4, loop);
                    
                        } 
                    } 
                } 
            }
            if (loop % 60 == 0) {
                for (int i = 0; i < cooldowns.length; i++) {
                    if (cooldowns[i] != 0) {
                        cooldowns[i]--;
                    }
                }
            }
            
            if (loop % 120 == 60 || loop % 120 == 0) {
                for (int i = 0; i < towers.length; i++) {
                    for (int j = towers[i].length-1; j >= 0 ; j-- ) {
                        if (towers[i][j] != null) {
                            if (towers[i][j] instanceof MythicCannon) {
                                towers[i][j].fireProjectile();
                            } else if (loop % 120 == 60) {
                                if (towers[i][j] instanceof SnowCannon) {
                                    towers[i][j].fireProjectile("slow");
                                } else if (towers[i][j] instanceof Cannon) {
                                    towers[i][j].fireProjectile();
                                }
                            } 
                            if (towers[i][j].getHealth() <= 0) {
                                towers[i][j] = null;
                            }      
                        }  
                             
                    } 
                }
                //updateEnemy();
            }
            updateEnemy();
            for (int i = 0; i < towers.length; i++) {
                for (int j = 0; j < towers[i].length; j++) {
                    if (towers[i][j] != null) {
                        if (towers[i][j] instanceof MythicCannon) {
                            towers[i][j].updateProjectiles(mythicCannonBullet); 
                        } else if (towers[i][j] instanceof SnowCannon) {
                            towers[i][j].updateProjectiles(snowCannonBullet); 
                        } else if (towers[i][j] instanceof Cannon) {
                            towers[i][j].updateProjectiles(cannonBullet); 
                        } 
                       
                        
                    }
                }            
                
            }
            
            for (int i = popUps.size()-1; i >= 0 ; i--) {
        
                int apperance = popUps.get(i).show();
                if (apperance == 80) {
                    popUps.remove(i);
                }
            }
            imageMode(CORNER);
            
            text(str(mouseX) + ", " + str(mouseY), 20, 20);
            
            if (loop == 6000) {
                loop = 0;
            }
            if (loop % 300 == 0) {
                cash+= 5;
            }
        
            if (loop % 2 != 0 && numOfDJ == 1) {
                loop++;
            }
            updateHealthBar();
            startGame();
            showTowerInfo();
        } else {
            textSize(80);
            fill(255);
            text("Game Over!", 115, 170);
        } 
    }
    public void showTowerInfo() {
        if (showTowerInfo != "null") {
            fill(255);
            rect(115,200, 384,192);
            rect(115,200,384,40);
            fill(0);
            fill(100);
            rect(115,240,125,152); 
            textSize(30);
            if (showTowerInfo.equals("info1")) {
                //Description
                text("Cannon",125,230);
                image(cannon1, 125,250);
                text("Damage: 3", 250,270);
                text("Firerate: 2 sec", 250, 310);
                textSize(13);
                text("Right click cannon again to hide GUI", 250, 340);
                
            } else if (showTowerInfo.equals("info2")) {
                //Description
                text("Apple Tree",125,230);
                image(appleTree3, 125,250);
                text("Stage 2: +$25", 250,270);
                text("Stage 3: +$100", 250, 310);
                textSize(13);
                text("Stage 1 is when there are no apples", 250, 330);
                text("Stage 2 takes on average 5 second to reach", 250, 345);
                text("Stage 3 takes on average 12 second to reach", 250, 360);
                text("Harvest the apples by left clicking them", 250, 375);
                text("Right click apple tree again to hide GUI", 250, 390);
            } else if (showTowerInfo.equals("info3")) {
                //Description
                text("DJ",125,230);
                image(DJ1, 140,250);
                text("Boost firerate 2x", 250,270);
                text("Takes up 2 tiles", 250, 300);
                text("Limit: 1 DJ", 250, 330);
                textSize(13);
                text("I planned to add music, but idk how", 250, 350);
                text("Right click DJ again to hide GUI", 250, 375);
            } else if (showTowerInfo.equals("info4")) {
                //Description
                text("Mythic Cannon",125,230);
                image(mythicCannon1, 125,250);
                text("Damage: 10", 250,270);
                text("Firerate: 1 sec", 250, 310);
                textSize(13);
                text("A cannon that has been enchanted with", 250, 325);
                text("mysterious exiler", 250, 335);
                text("Right click cannon again to hide GUI", 250, 350);
            } else if (showTowerInfo.equals("info5")) {
                //Description
                text("Snow Cannon",125,230);
                image(snowCannon1, 125,250);
                text("Damage: 3", 250,270);
                text("Firerate: 2 sec", 250, 310);
                text("Slow debuff: 25%", 250, 340);
                
                textSize(13);
                text("Slow stacks 3x", 250, 355);
                text("A cannon power by snow", 250, 370);
                text("Right click snow cannon again to hide GUI", 250, 385);
            }  else if (showTowerInfo.equals("info6")) {
                //Description
                text("Stone Head",125,230);
                image(stoneHead1, 125,250);
                text("Health: 72", 250,270);
                textSize(13);
                text("A tank that stalls enemy", 250, 355);
                text("Right click stone head again to hide GUI", 250, 385);
            }
        }
    }
    public void startGame() {
        int row = (int) (Math.random() * 6);
        if (time <= 900) {
            text("Wave: 1/5", 275,20);
            
            if (enemyLoop % 300 == 0) {
                //public Enemy(PApplet p, PImage enemy, String name, int health, int speed, int damage,int xPos, int yPos, int row, Tower[] towers) {
                Enemy enemy = new Enemy(this, slime, "Slime", 10, 12, 1, 565, 100 + row*64, row, towers[row]);
                enemies[row].add(enemy);
             
         
            }
  

            
    
                    
        } else if (time <= 2000) {
            
            text("Wave: 2/5", 275,20);
           
            if (enemyLoop % 250 == 0) {
               
                Enemy enemy = new Enemy(this, slime, "Slime", 10, 12, 1, 565, 100 + row*64, row, towers[row]);
                enemies[row].add(enemy);
            }
            if (enemyLoop % 1000 == 0) {
                row = (int) (Math.random() * 6);
                Enemy enemy = new Enemy(this, skeleton, "Skeleton", 50, 10, 2, 565, 75 + row*64,row, towers[row]);
                enemies[row].add(enemy);
            }
            
    
        } else if (time <= 4500) {
            
            text("Wave: 3/5", 275,20);
            if (enemyLoop % 200 == 0) {
               
                Enemy enemy = new Enemy(this, slime, "Slime", 10, 12, 1, 565, 100 + row*64, row, towers[row]);
                enemies[row].add(enemy);
            }
            if (enemyLoop % 625 == 0) {
                row = (int) (Math.random() * 6);
                Enemy enemy = new Enemy(this, skeleton, "Skeleton", 50, 10, 2, 565, 75 + row*64,row, towers[row]);
                enemies[row].add(enemy);
            }
            if (enemyLoop % 2500 == 0) {
                row = (int) (Math.random() * 5);
                Boss enemy = new Boss(this, boss, "Boss", 200, 6, 3,565, 25+ row*64,row, towers, 2);
                bosses.add(enemy);
            }

    
        } else if (time <= 8000) {
            text("Wave: 4/5", 275,20);
            if (enemyLoop % 180 == 0) {
               
                Enemy enemy = new Enemy(this, slime, "Slime", 10, 12, 1, 565, 100 + row*64, row, towers[row]);
                enemies[row].add(enemy);
            }
            if (enemyLoop % 500 == 0) {
                row = (int) (Math.random() * 6);
                Enemy enemy = new Enemy(this, skeleton, "Skeleton", 50, 10, 2, 565, 75 + row*64,row, towers[row]);
                enemies[row].add(enemy);
            }
            if (enemyLoop % 1150 == 0) {
                row = (int) (Math.random() * 5);
                Boss enemy = new Boss(this, boss, "Boss", 200, 6, 3,565, 25+ row*64,row, towers, 2);
                bosses.add(enemy);
            }
        } else if (time <= 12000) {
            bossWaveText("BOSS WAVE!!!",250,20, 30);
            if (enemyLoop % 150 == 0) {
               
                Enemy enemy = new Enemy(this, slime, "Slime", 10, 12, 1, 565, 100 + row*64, row, towers[row]);
                enemies[row].add(enemy);
            }
            if (enemyLoop % 400 == 0) {
                row = (int) (Math.random() * 6);
                Enemy enemy = new Enemy(this, skeleton, "Skeleton", 50, 10, 2, 565, 75 + row*64,row, towers[row]);
                enemies[row].add(enemy);
            }
            if (enemyLoop % 800 == 0) {
                row = (int) (Math.random() * 5);
                Boss enemy = new Boss(this, boss, "Boss", 200, 6, 3,565, 25+ row*64,row, towers, 2);
                bosses.add(enemy);
            }
            if (enemyLoop % 10000 == 8500) {
                //  public Boss(PApplet p, PImage enemy, String name, int health, int speed, int damage,int xPos, int yPos, int row, Tower[][] towers, int rowSize) {
                row = (int) (Math.random()*4);
                Dragon enemy = new Dragon(this, dragon1, "Boss", 5000, 16, 6,565, 25+ row*64,row, towers, 3, map);
                enemy.setup();
                bosses.add(enemy);
            }

            //Add
        } else if (enemyCount <= 50000) {

            for (int i = 0; i < enemies.length;i++) {
                enemyCount += enemies[i].size();
            }
            if (enemyCount == 0) {
                bossWaveText("Triumph!!!", 115, 255, 80);
                win = true;
            }
        }
        for (int i = 0; i < enemies.length; i++) {
            for (int j = 0; j < enemies[i].size(); j++) {
                enemies[i].get(j).updateEnemy(enemyLoop);
            }
        }
       
        for (int j = 0; j < bosses.size(); j++) {
            bosses.get(j).updateEnemy(enemyLoop);
        }
        if (time > bossTime-120 && time < bossTime) {
            background(0);
            for (int i = -50; i < 600; i++) {
                
                for (int j = -50; j < 600; j++) {
                    
                    int red = (int) (Math.random() * 140)+115;
                    int green = (int) (Math.random() * 140)+115;
                    int blue = (int) (Math.random() * 140)+115;
                    fill(red, green, blue);
                    rect(i,j,60+enemyLoop%250,60+enemyLoop%250);
                    j+=(int) (Math.random() * 10);
                }
                i+= (int) (Math.random() * 180);
            }
            if (time%60 <= 30) {
                bossWaveText("BOSS WAVE!!!", 115, 255, 80);
            }
            
        }
        //cash++;
    }
    public void updateEnemy() {
        
      
     
        for (int i = 0; i < enemies.length; i++) {
            for (int j = enemies[i].size() -1; j >= 0; j--) {
                
                int enemyHealth = enemies[i].get(j).getHealth();
                if (enemyHealth <= 0) {
                    cash += enemies[i].get(j).getReward();
                    enemies[i].remove(j);
                } else if (enemies[i].get(j).getXPos() < 0) {
                    baseHealth -= enemyHealth;
                    enemies[i].remove(j);
                } else {
                    enemies[i].get(j).attackTower();
                }
            }
        }
     
        for (int j = bosses.size() -1; j >= 0; j--) {
            int bossesHealth = bosses.get(j).getHealth();
            if (bossesHealth <= 0) {
                cash += bosses.get(j).getReward() * 5;
                bosses.remove(j);
            } else if (bosses.get(j).getXPos() < 50) {
                baseHealth -= bossesHealth;
                bosses.remove(j);
            } else {
                bosses.get(j).attackTower();
                if (bosses.get(j) instanceof Dragon) {
                    if (time%500 == 0) {
                        bosses.get(j).fireBreathAttack();
                    }
                }
            }
            
        }
   


    }
    public void keyPressed() {
        if (key == 'q' || key == 'Q') {
            isTrashing = false;
            placingTower = false;
            lastTowerSelected = "null";
        }
    }
    public void mousePressed() {

        int x = mouseX;
        int y = mouseY;
        String below = getBelowMouse(x, y);
        if (below.indexOf("/") != -1) {
                int row = Integer.parseInt(below.substring(0, below.indexOf("/")));
                int col = Integer.parseInt(below.substring(below.indexOf("/") + 1));

                x = 50+(col*64)+32;
                y = 75+(row*64)+32;
            if (placingTower) {
          
                if (lastTowerSelected.equals("slot1")) {
                    //public Cannon(PApplet p, int damage, double fireRate, double price, int xPos, int yPos, int row, ArrayList<Enemy> enemies) {
                    Cannon cannon = new Cannon(this, 3, 2, 50, x, y, row, enemies[row], bosses, 6);
                 
                    towers[row][col] = cannon;
                    cash -= 50;
                    popUps.add(new PopUp(this, "money", "-50"));
                    cooldowns[0] = 4;
                    lastTowerSelected = "null";
                    
                } else if (lastTowerSelected.equals("slot2")) {
                    //public Farm(PApplet p, double price, int xPos, int yPos, int row) {
                    Farm farm = new Farm(this, 250, x, y, row, 6);
                    towers[row][col] = farm;
                    cash -= 150;
                    popUps.add(new PopUp(this, "money", "-150"));
                    cooldowns[1] = 10;
                    lastTowerSelected = "null";
                } else if (lastTowerSelected.equals("slot3")) {
                    //public DJ(PApplet p, double price, int xPos, int yPos, int row) {
                    DJ dj = new DJ(this, 1000, x, y+35, row, 18);
                    towers[row][col] = dj;
                    towers[row+1][col] = dj;
                    cash -= 5000;
                    popUps.add(new PopUp(this, "money", "-5000"));
                    cooldowns[2] = 60;
                    lastTowerSelected = "null";
                } else if (lastTowerSelected.equals("slot4")) {
                    MythicCannon mythicCannon = new MythicCannon(this, 10, 1, 500, x, y, row, enemies[row], bosses, 8);
                    towers[row][col] = mythicCannon;
                    cash -= 500;
                    popUps.add(new PopUp(this, "money", "-500"));
                    cooldowns[3] = 30;
                    lastTowerSelected = "null";
                } else if (lastTowerSelected.equals("slot5")) {
                    SnowCannon snowCannon = new SnowCannon(this, 3, 2, 250, x, y, row, enemies[row], bosses, 6);
                    towers[row][col] = snowCannon;
                    cash -= 250;
                    popUps.add(new PopUp(this, "money", "-250"));
                    cooldowns[4] = 14;
                    lastTowerSelected = "null";
                } else if (lastTowerSelected.equals("slot6")) {
                    //public StoneHead(PApplet p, double price, int xPos, int yPos, int row, int health) {
                    StoneHead stoneHead = new StoneHead(this, 100, x, y, row, 72);
                    towers[row][col] = stoneHead;
                    cash -= 100;
                    popUps.add(new PopUp(this, "money", "-100"));
                    cooldowns[5] = 30;
                    lastTowerSelected = "null";
                }
                
                System.out.println("Success!");
                placingTower = false;
            } else if (isTrashing) {
                if (towers[row][col] instanceof DJ) {
                    numOfDJ = 0;
                    if (row < 5 && towers[row+1][col] instanceof DJ) {
                        towers[row+1][col] = null;
                    } else {
                        towers[row-1][col] = null;
                    }
                    
                }
                towers[row][col] = null;
                isTrashing = false;
            } else if (towers[row][col] instanceof Farm) {
                int collected = towers[row][col].collectMoney();
                popUps.add(new PopUp(this, "money", "" + collected));
                cash += collected;
            } 

            return;
        } else if (placingTower) {
            System.out.println("Out of bound placement!");
        }
        if (below.equals("slot1") || below.equals("slot2") || below.equals("slot3") || below.equals("slot4") || below.equals("slot5") || below.equals("slot6")) {
            placingTower = true;
            System.out.println("place your tower somewhere!");

        }
       
    }
    public String getBelowMouse(int x, int y) {
       
        if (!placingTower && x>100 && x<520 && y > 500 && y < 575) { //Buy towers
            if (x > 100 && x < 170) {
                if (mouseButton == LEFT) {
                    if (cash >= 50) {
                        if (cooldowns[0] == 0) {
                            lastTowerSelected = "slot1";
                            return "slot1";
                        } 
                        return "null";
                 
                    } 
                } else {
                    if (!showTowerInfo.equals("info1")) {
                        showTowerInfo = "info1";
                        return "null";
                    } 
                    
                }
                
            } else if (x > 170 && x < 240) {
                if (mouseButton == LEFT) {
                    if (cash >= 150) {
                        if (cooldowns[1] == 0) {
                            lastTowerSelected = "slot2";
                            return "slot2";
                        } 
                        return "null";
                    }
                } else {
                    if (!showTowerInfo.equals("info2")) {
                        showTowerInfo = "info2";
                        return "null";
                    } 
                }
             
                  
            } else if (x > 240 && x < 310) {
                if (mouseButton == LEFT) {
                    if (cash >= 5000 ) {
                        if (numOfDJ == 0) {
                            if (cooldowns[2] == 0) {
                                lastTowerSelected = "slot3";
                                return "slot3";
                            }           
                        } else {
                            System.out.println("Only maximum of 1 DJ is allow");
                        }          
                        return "null";
                    }
                } else {
                    if (!showTowerInfo.equals("info3")) {
                        showTowerInfo = "info3";
                        return "null";
                    } 
                }

                
            } else if (x > 310 && x < 380) {
                if (mouseButton == LEFT) {
                    if (cooldowns[3] == 0) {
                            lastTowerSelected = "slot4";
                            return "slot4";
                    }
                    return "null";   
                } else {
                    if (!showTowerInfo.equals("info4")) {
                        showTowerInfo = "info4";
                        return "null";
                    } 
                }
          
            } else if (x > 380 && x < 450) {
                if (mouseButton == LEFT) {
                    if (cash >= 250) {
   
                        if (cooldowns[4] == 0) {
                            lastTowerSelected = "slot5";
                            return "slot5";
                        } 
                       
                    }
                     return "null";
                } else {
                    if (!showTowerInfo.equals("info5")) {
                        showTowerInfo = "info5";
                         return "null";
                    } 
                }
               
            } else if (x > 450 && x < 520) {
                if (mouseButton == LEFT) {
                    if (cash >= 100) {

                        if (cooldowns[5] == 0) {
                            lastTowerSelected = "slot6";
                            return "slot6";
                        } 
                        
                    }
                     return "null";
                } else {
                    if (!showTowerInfo.equals("info6")) {
                        showTowerInfo = "info6";
                        return "null";
                    }    
                }
               
            }
            showTowerInfo = "null";
            if (mouseButton == RIGHT) {
                System.out.println("not enough money :(");
            }
            return "null";
        }
        if (x > 50 && x < 562 && y > 75 && y < 460) {
            for (int i = 50; i < 500; i+= 64) {
                for (int j = 75; j < 450; j+= 64) {
                    if (x > i && x < i + 64 && y > j && y < j+64) {
                        int col = (i-50)/64;       
                        int row = (j-75)/64;
               
                        if (towers[row][col] == null || isTrashing) {
                     
                            if (lastTowerSelected == "slot3" && row < 5 && towers[row+1][col] == null) {
                               
                                return "" + row + "/" + col;
                            } else if (lastTowerSelected != "slot3") {
                                
                                return "" + row + "/" + col;
                            }
                            
                        } else if (!placingTower && towers[row][col] instanceof Farm) {
                            return "" + row + "/" + col;
                        }
                    }
                    
                }
            } 
            System.out.println("Tower already here");
            return "error";
        } 

        if (x > 540 && x < 580 && y > 520 && y < 560) {
            System.out.println("select a cell to delete tower");
            isTrashing = true;

            return "trash";
        }

        return "null";
    }
    public void bossWaveText(String text,int xPos, int yPos, int size) {
        if (enemyLoop % 60 < 10) {
                fill(255, 0, 0);
            } else if (enemyLoop % 60 < 20) {
                fill(255, 127, 0);
            } else if (enemyLoop % 60 < 30) {
                fill(255, 255, 2);
            } else if (enemyLoop % 60 < 40) {
                fill(0, 255, 2);
            } else if (enemyLoop % 60 < 50) {
                fill(0, 0, 226);
            } else {
                fill(153, 0, 255);
            }        
            textSize(size);
            text(text, xPos,yPos);
    }
    public void characterBar() {
        strokeWeight(4);
        
        fill(0,250,0);
        stroke(51);
        textSize(30);
        text("Cash", 25, 520);
        textSize(20);
        text("$" + cash, 25, 550);
        
        fill(255);
        //Tower 1
        rect(100,500,70,75);
        image(cannon1, 87.5F, 485);
        text("$50", 120, 500);
        
        //Tower 2
        rect(170,500,70,75);
        image(appleTree1, 157.5F, 485);
        text("$150", 190, 500);
        
        //Tower 3
        rect(240,500,70,75);
        image(DJ1,245.5F, 485);
        text("$5000", 250, 500);
        
        //Tower 4
        rect(310,500,70,75);
        image(mythicCannon1, 300.5F, 485);
        text("$500", 330, 500);
        
        //Tower 5
        rect(380,500,70,75);
        image(snowCannon1, 370.5F, 485);
        text("$250", 400, 500);
        //Tower 6
        rect(450,500,70,75);
        image(stoneHead1, 455.5F, 485);
        text("$100", 470, 500);
        textSize(40);
        if (cooldowns[0] != 0) {
            fill(0);
            int pos = 75*cooldowns[0]/4;
            rect(100,500,70,pos);
            fill(255);

            text(cooldowns[0], 125,550);
        }
        if (cooldowns[1] != 0) {
            fill(0);
            int pos = 75*cooldowns[1]/10;
            rect(170,500,70,pos);
            fill(255);
            text(cooldowns[1], 195,550);
        }
        if (cooldowns[2] != 0) {
            fill(0);
            int pos = 75*cooldowns[2]/60;
            rect(240,500,70,pos);
            fill(255);
            text(cooldowns[2], 265,550);
        }
        if (cooldowns[3] != 0) {
            fill(0);
            int pos = 75*cooldowns[3]/30;
            rect(310,500,70,pos);
            fill(255);
            text(cooldowns[3], 335,550);
        }
        if (cooldowns[4] != 0) {
            fill(0);
            int pos = 75*cooldowns[4]/14;
            rect(380,500,70,pos);
            fill(255);
            text(cooldowns[4], 405,550);
        }
        if (cooldowns[5] != 0) {
            fill(0);
            int pos = 75*cooldowns[5]/30;
            rect(450,500,70,pos);
            fill(255);
            text(cooldowns[5], 470,550);
        }

        rect(540, 520, 40,40);
        image(trash, 545.5F, 520);
    }

    public void updateWave() {
        text("Wave: 1/5", 275,20);
    }
    public void updateHealthBar() {
        //bar
        fill(0);
        rect(50,25,500,30);
        //health bar
        fill(0,204,102);
        rect(50,25,baseHealth,30); //x-500, y-30 long health bar
     
        fill(255);
        if (baseHealth < 0) {
            baseHealth = 0;
            textSize(40);
            lost = true;
            
        }
        text(baseHealth + "/" + maxHealth + "" + "HP", 275, 45);
    
    }  
  
}
