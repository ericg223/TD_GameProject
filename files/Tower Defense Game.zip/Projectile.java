import processing.core.PApplet;
import java.util.ArrayList;
public class Projectile{

    private int damage, xPos, yPos, row, time;
    private String effect;
    public Projectile(int damage, int xPos, int yPos, int row) {
        this.damage = damage;
        this.xPos = xPos;
        this.yPos = yPos;
        this.row = row;
        this.effect = null;
        this.time = 0;
    }
    public Projectile(int damage, int xPos, int yPos, int row, String effect) {
        this.damage = damage;
        this.xPos = xPos;
        this.yPos = yPos;
        this.row = row;
        this.effect = effect;
    }
    public boolean touchedEnemy(ArrayList<Enemy> enemies, ArrayList<Boss> bosses) {
        
        for (int i = 0; i < enemies.size(); i++) {
            int enemyXPos = enemies.get(i).getXPos();
       
            if (xPos-enemyXPos <= 0 && xPos + 5 > enemyXPos) {
                enemies.get(i).updateHealth(damage);

                if (effect != null && effect.equals("slow")) {
                    enemies.get(i).updateWalkSpeed(0.25);
                }
                return true;
            } 
        }
        for (int i = 0; i < bosses.size(); i++) {
            int bossXPos = bosses.get(i).getXPos();
            int bossRow = bosses.get(i).getRow();

            int bossRowSize = bosses.get(i).getRowSize();
            if (xPos-bossXPos <= 0 && xPos + 5 > bossXPos) {
                for (int j = 0; j < bossRowSize; j++) {
                    if (row == bossRow + j) {
                        
                        bosses.get(i).updateHealth(damage);
                        if (effect != null && effect.equals("slow")) {
                            bosses.get(i).updateWalkSpeed(0.25);
                        }
                        return true;
                    }
                }
            } 
     
        }
       
        return false;
    }
    public void updateProjectile(int xSpeed, int ySpeed) {
        xPos += xSpeed;
        yPos += ySpeed;
    }
    public int getXPos() {
        return xPos;
    }
    public int getYPos() {
        return yPos;
    }
    public int getTime() {
        return time;
    }
    public void addTime() {
        time++;
    }
  

}