import processing.core.PApplet;
import processing.core.PImage;

import java.util.ArrayList;
public class DJ extends Tower{
    private double fireRate;
    private int damage;
    private ArrayList<Projectile> projectiles = new ArrayList<Projectile>();
    private PApplet p;
    private ArrayList<Enemy> enemies;
    private int stageLevel = 1;
    //private PImage DJAura;

   

    public DJ(PApplet p, double price, int xPos, int yPos, int row, int health) {
        super(p, price, xPos, yPos, row, health);
        this.damage = damage;
        this.fireRate = fireRate;
        this.p = p;
        this.enemies = enemies;

   

    }

   
    public void playTowerAnimation(PImage DJ1, PImage DJ2, PImage DJ3, int time) {
       
        if (stageLevel == 1) {
            
            if (time%300 == 0) {
                stageLevel = 2;
                p.image(DJ2, (float) super.getXPos(), (float) super.getYPos());
                return;
            } 
            p.image(DJ1, (float) super.getXPos(), (float) super.getYPos());
        } else if (stageLevel == 2) {
            if (time%750 == 0) {
                stageLevel = 3;
                p.image(DJ3, (float) super.getXPos(), (float) super.getYPos());
                return;
            }
            p.image(DJ2, (float) super.getXPos(), (float) super.getYPos());
            
        } else {
            p.image(DJ3, (float) super.getXPos(), (float) super.getYPos());
        }
        

    }
   
   
  

}